Thank you for your download!

Discord:
https://discord.gg/p5xajUAwa8

MythicMobs:
1. Place the mob file in the Mobs folder. plugins --> MythicMobs --> Mobs
   Place the skill file in the Skills folder. plugins --> MythicMobs --> Skills
2. In minecraft, write command /mm reload

ModelEngine:
1. Drag and drop bbmodel file of the mob inside the blueprints folder. plugins --> ModelEngine --> blueprints
2. In minecraft, write command /meg reload
3. Create the resource pack. plugins --> ModelEngine --> resource pack, select all (assets, pack.mcmeta and pack.png) and download
   OR
   You can download the resource pack.zip after refreshing the page if this is available
4. Place the resource pack in minecraft.




If you want to change how much damage a mob does, go to <mob.name> skills.yml and NOT <mob.name> mob.yml
# 6s59JJ5O0V8Irfxet3I4H7MYPA7j1F1OC6LSxUU0/w/Viqh2TlSVqn25w1+H1aKGdIn6BRKSSTwn4bAyT1fIkuWNKekZN3JJnvZTgowu75o=