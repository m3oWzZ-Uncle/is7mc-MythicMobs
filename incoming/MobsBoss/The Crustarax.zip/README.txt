Hi!

Thanks for purchasing our product!

Please keep in mind that by purchasing or using our products, including those acquired through other platforms (e.g., MCModels, BuiltByBit, etc.), you agree to our following Terms of Service, which can be found below, and supersede any other terms included in product files.

Terms of Service:
All products are the intellectual property of Justice Studios.

Our products cannot be resold or distributed. Unauthorized activities, such as piracy or reselling, will result in legal action. Such actions can lead to serious consequences, including felony charges, up to five years in prison, and fines of up to $250,000.

You are welcome to modify the models, textures, and MythicMobs files for use in your own servers or content. When using our products in videos or streams, please credit us as follows (copy and paste):

```
For any questions or issues, feel free to reach out to us on our Discord!

Models/Textures by arlug08, 'arlug' on Discord
Animations/Configurations by Miscodes, 'miscodes' on Discord

NOT AN OFFICIAL MINECRAFT PRODUCT. NOT APPROVED BY OR ASSOCIATED WITH MOJANG.
```

Alternatively, you can choose to provide payment or advertisement instead of leaving credits.

Thank you for choosing Justice Studios!

- Justice Studios.