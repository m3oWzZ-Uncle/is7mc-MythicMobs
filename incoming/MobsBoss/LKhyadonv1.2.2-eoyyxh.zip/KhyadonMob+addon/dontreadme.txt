Hey! You purchased assets made with love. 

Please land into my DISCORD to receive support, and to see more cool stuff!

======================================
https://discord.gg/tNkpg86WHd
==============================================

This asset requires verification on discord to access little upgrades, and access to the little community of Khyadon's devotes!


This is a whole Boss mob for crushing your server, Lord Khyadon!

Lord Khyadon is the leader of a dark magi cult. He is the only mortal that has been able to control the full power of the
Ethernal darkness Staff. You are in between his plans of destroying all light, and him. You definitely are in trouble!

This contains:

- A Bbmodel file: The core of the animations and modeling. 
- MythicMobs Mob (10 mobs), Skills (more than 850 lines.. wow!), and one 8 items. They're all necessary for the boss to work 

   (THEY COME PACKED IN THEIR FOLDER STRUCTURE, SO YOU CAN DRAG AND DROP THEM UNDER SERVER FOLDER/PLUGINS)

- The resource pack. Althought ModelEngine will generate its own, you need the custom sounds and the emissive texture for his eyes to glow.

You can modify certain atttributes to fine tune the boss' strenght to your server. The 'imaginary boots' are items designed to
increase resistance and add some perks to make the boss less exploitable. You can also increase/decrease the armor values to
further customize the resistance values.

HOW TO INSTALL:

1) Place 'gononeita' in your ModelEngine/Blueprints folder.
2) Merge the Assets folder inside 'LordKhyadon' with your current resourcepack. (Important note, if you plan to add more custom
sounds, you must beware of the SOUNDS json under Assets/Minecraft, or else they'll override) Also, if you buy various assets, you
can request a merged JSON for all the models.
3) Generate the ModelEngine resourcepack, and merge that one with your new Resource pack.
4) Install the MythicMobs Config by dragging and dropping the "MythicMobs" folder included here.
5) Reload your resource pack.



Made with love,
Endesman
