
MythicMobs:

1. Place the file with the "(Mods)" suffix into the following directory: plugins/MythicMobs/mobs.

2. For custom skills, add the file with the "(Skills)" suffix into this folder: plugins/MythicMobs/skills.

3. Once everything is set up, run the /mm reload command to load the new configurations.

------------------------------------------------------------------------------------------------------------------------------------

ModelEngine:

1. Place the .bbmodel files into the folder: plugins/ModelEngine/blueprints.

2. After that, update ModelEngine settings by running the /meg reload command.

3. Navigate to the plugins/ModelEngine folder and locate the resource pack's .zip file.

4. Add this .zip file as a resource pack in your Minecraft client.

------------------------------------------------------------------------------------------------------------------------------------

Resource Pack Instructions:
If the purchased pack includes any of the following folders or files:

"sounds", "sounds.json", "font", "textures", or "optifine",
move them to your resource pack directory under:
assets/minecraft

If the pack contains .mcmeta files, move them to:
assets/minecraft/modelengine/textures/entity

(Refer to the example provided in the .zip resource pack included in this package to understand the correct folder structure.)

Attention!!!
The .zip resource pack included in this package is provided only as a reference.
Its sole purpose is to help you understand how to correctly organize folders and files.

------------------------------------------------------------------------------------------------------------------------------------
#e3be0d2dcb65af13ff1d153a5e5728cf
#26b303577f3118cf5764cff90602af79
# y7ZleOMOf7Tt7g+rfzdYsgtqCT5MMQtMYIV611aIeaYBckrqJyipBgGmLzojXtIlPA+Cj/7bodjzeKC1yqtlMKCmtRTVKjGnU4aiMqXJ1oE=