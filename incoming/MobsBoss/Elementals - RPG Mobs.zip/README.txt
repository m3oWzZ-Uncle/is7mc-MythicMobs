Thank you for your download!

Discord:
bojarsky

MythicMobs:
1. Place the mob file in the Mobs folder. plugins --> MythicMobs --> Mobs
   Place the skill file in the Skills folder. plugins --> MythicMobs --> Skills
2. In minecraft, write command /mm reload

ModelEngine:
1. Drag and drop bbmodel file of the mob inside the blueprints folder. plugins --> ModelEngine --> blueprints
2. In minecraft, write command /meg reload
3. Create the resource pack. plugins --> ModelEngine --> resource pack, select all (assets, pack.mcmeta and pack.png) and download
   OR
   You can download the resource pack.zip after refreshing the page if this is available
4. Place the resource pack in minecraft.

IMPORTANT!
After creating the resource pack, go to resource pack.zip --> assets --> textures --> entity
And change the line from “frametime”:1 to “frametime”:3 in all .mcmeta files!

If you want to change how much damage a mob does, go to <mob.name> skills.yml and NOT <mob.name> mob.yml