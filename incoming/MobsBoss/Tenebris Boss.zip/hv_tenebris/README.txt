
MythicMobs:

1. Place the file with the "(Mods)" suffix into the following directory: plugins/MythicMobs/mobs.

2. For custom skills, add the file with the "(Skills)" suffix into this folder: plugins/MythicMobs/skills.

3. Once everything is set up, run the /mm reload command to load the new configurations.

------------------------------------------------------------------------------------------------------------------------------------

ModelEngine:

1. Place the .bbmodel files into the folder: plugins/ModelEngine/blueprints.

2. After that, update ModelEngine settings by running the /meg reload command.

3. Navigate to the plugins/ModelEngine folder and locate the resource pack's .zip file.

4. Add this .zip file as a resource pack in your Minecraft client.

------------------------------------------------------------------------------------------------------------------------------------

Resource Pack Instructions:

If the purchased pack includes "sounds", "sounds.json", "font", "textures", or "optifine" folders or files, move them to your resource pack directory under:
assets/minecraft
(You can refer to the example in the .zip resource pack provided in this package.)

Attention!!!

The .zip resource pack included in this package is only provided as a reference. 
Its purpose is to help you understand how to properly organize your folders and files.

------------------------------------------------------------------------------------------------------------------------------------