Thank you for your download!

Discord:
bojarsky

MythicMobs:
1. Place the mob file in the Mobs folder. plugins --> MythicMobs --> Mobs
   Place the skill file in the Skills folder. plugins --> MythicMobs --> Skills
2. In minecraft, write command /mm reload

ModelEngine:
1. Drag and drop bbmodel file of the mob inside the blueprints folder. plugins --> ModelEngine --> blueprints
2. In minecraft, write command /meg reload
3. Create the resource pack. plugins --> ModelEngine --> resource pack, select all (assets, pack.mcmeta and pack.png) and download
   OR
   You can download the resource pack.zip after refreshing the page if this is available
4. Place the resource pack in minecraft.

If you want to change how much damage a mob does, go to <mob.name> skills.yml and NOT <mob.name> mob.yml
#0bacbd4940c1c67b4c9c1fe1223a3398
# +UasEV9eZa48PFOu/M5u+a3WNlckoXSchqzn6ZA2w7iqkgmCro+eho16HGFFGoZeeA8zOx48QZVssylHVAQDehl3e39mxpzZrix74lHi1N8=