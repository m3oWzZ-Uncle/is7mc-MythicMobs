For support please join our discord link: https://discord.gg/fz8GPg7KZr

###############################
1.- How to install the Mob:
###############################

https://mcmodels.net/how-to-tutorials/modelengine-tutorials/how-to-install-pre-made-model-engine-mythicmobs-packages/

###############################
2.- How to install the Arena:
###############################

- Put arenaErgeoxBoss.schem in \plugins\WorldEdit\schematics.

- Use: //schem load arenaErgeoxBoss

- Use: //paste (wherever you want to put the arena)


- 8w8
# 7jxloP2LoIR0Z3wqYNk45LPp3WTIL2jteO/aKp2uQbU23ntdXA8rlIMusuIM5OelXouplAIA7h78YXI2EZZ/BZGXX2Kqn/Mg2hfAcWoTSCc=