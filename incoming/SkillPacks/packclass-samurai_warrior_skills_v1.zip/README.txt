﻿███╗░░░███╗██╗░░░██╗████████╗██╗░░██╗██╗░█████╗░░░░░░░███╗░░░███╗███╗░░░███╗░█████╗░
████╗░████║╚██╗░██╔╝╚══██╔══╝██║░░██║██║██╔══██╗░░░░░░████╗░████║████╗░████║██╔══██╗
██╔████╔██║░╚████╔╝░░░░██║░░░███████║██║██║░░╚═╝█████╗██╔████╔██║██╔████╔██║██║░░╚═╝
██║╚██╔╝██║░░╚██╔╝░░░░░██║░░░██╔══██║██║██║░░██╗╚════╝██║╚██╔╝██║██║╚██╔╝██║██║░░██╗
██║░╚═╝░██║░░░██║░░░░░░██║░░░██║░░██║██║╚█████╔╝░░░░░░██║░╚═╝░██║██║░╚═╝░██║╚█████╔╝
╚═╝░░░░░╚═╝░░░╚═╝░░░░░░╚═╝░░░╚═╝░░╚═╝╚═╝░╚════╝░░░░░░░╚═╝░░░░░╚═╝╚═╝░░░░░╚═╝░╚════╝░

MythicMMC Ch PRESENTS...

Request:
	- MythicMobs-5.2.0 Premium
	- MythicLib-1.4.2
	- MMOCore-1.10.2
	- LibsDisguises
	- ItemsAdder_3.3.0 or Orixen 1.148.2
	- placeholder
	- ModelEngine

Installation Instructions:
STEP 1:
You can either use the provided resourcepack zip file provided for your server or you can combine it with your current
resourcepack although it may prompt you that its going to overwrite the that is standard 

STEP 2:
Please make sure you have MythicMobs and MMOCore and ItemsAdder installed, the free versions should work just fine.
Copy both 'Config to ItemsAdder' or 'Config to Oraxen' into your plugins folder of your server.

STEP 3:
Restart the server and check it out

How to use:
	- Run command /mm items give <player> SAMURAI_WARRIOR

Feel free to come to me for any questions or help at, https://discord.gg/Z7zrFnujD4
# GlT3rWZrq5DroCue1X1srsCyW9FUKkYS2Yf0sg1MOyFGskFPcIthjA/cw4JbIFt9Sbf3l+moALOECPHT2WC2q5U5kgIwYH3e6nCE5zMAj+8=