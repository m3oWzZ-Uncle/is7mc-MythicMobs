
██╗░░██╗███████╗██╗░░░░░██╗░░░░░░█████╗░░██╗░░░░░░░██╗░█████╗░██████╗░██╗░░░░░██████╗░
██║░░██║██╔════╝██║░░░░░██║░░░░░██╔══██╗░██║░░██╗░░██║██╔══██╗██╔══██╗██║░░░░░██╔══██╗
███████║█████╗░░██║░░░░░██║░░░░░██║░░██║░╚██╗████╗██╔╝██║░░██║██████╔╝██║░░░░░██║░░██║
██╔══██║██╔══╝░░██║░░░░░██║░░░░░██║░░██║░░████╔═████║░██║░░██║██╔══██╗██║░░░░░██║░░██║
██║░░██║███████╗███████╗███████╗╚█████╔╝░░╚██╔╝░╚██╔╝░╚█████╔╝██║░░██║███████╗██████╔╝
╚═╝░░╚═╝╚══════╝╚══════╝╚══════╝░╚════╝░░░░╚═╝░░░╚═╝░░░╚════╝░╚═╝░░╚═╝╚══════╝╚═════╝░

HelloWorld Ch PRESENTS...

Request:
	- MythicMobs-5.1.3-SNAPSHOT
	- MythicLib-1.4.1
	- MMOCore-1.10.2
	- LibsDisguises
	- ItemsAdder

Installation Instructions:
STEP 1:
You can either use the provided resourcepack zip file provided for your server or you can combine it with your current
resourcepack although it may prompt you that its going to overwrite the that is standard 

STEP 2:
Please make sure you have MythicMobs and MMOCore and ItemsAdder installed, the free versions should work just fine.
Copy both 'MythicMobs' and 'MMOCore' and 'ItemsAdder' into your plugins folder of your server.

STEP 3:
Restart the server and check it out

How to use:
	- Run command /mmocore admin class <player> CHAIN

Feel free to come to me for any questions or help at, https://discord.gg/pGJyJzJQvk
# 4Co7hzMCxDja6HLG135i7Z+iWX0QfZbHOBVjQ8L5sKYoe5T8uS81vI+G9of7VE61PM1j4RL7B0GMjyX06cEpbNKXr7xSKc11Dwg9+IKnreQ=