#version 150

#moj_import <fog.glsl>
#moj_import <hsv.glsl>

const float RAINBOW_SPEED = 100.0;

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float GameTime;

in float vertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;
in vec4 normal;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * ColorModulator;
    if (color.a < 0.1) discard;
    if (color.a == (254.0 / 255.0)){
        color.rgb *= hsv2rgb(vec3(GameTime * RAINBOW_SPEED, 1.0, 1.0));
    } else if (color.a <= 253.0 / 255.0) {
        if(color.a >= 150.0/255.0){
            color.a = 5.0;
        }
    } else {
        color *= vertexColor;
    }
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);

    
}
