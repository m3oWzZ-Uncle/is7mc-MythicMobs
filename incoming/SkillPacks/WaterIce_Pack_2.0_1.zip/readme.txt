Thank you for purchase<3
WaterIcePack 2022 made by Kapitan_787
How to get items in the game:
Left Click Aqua Slash

Right Click Aqua Smash
  Cooldown: 10

Shift Right Click water wave
 Cooldown: 5

Shift Left Click Rain of frozen swords
 Cooldown: 15

have fun