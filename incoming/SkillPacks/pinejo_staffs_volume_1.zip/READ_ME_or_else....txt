HI!

Insert the folder inside MythicMobs/packs/ inside your mythicmobs packs folder. (folder that you should upload is p_staffs_vol1)
I used mythic crucible rp generation, so use that.

#3da47706607c96acf85876189339d6b1