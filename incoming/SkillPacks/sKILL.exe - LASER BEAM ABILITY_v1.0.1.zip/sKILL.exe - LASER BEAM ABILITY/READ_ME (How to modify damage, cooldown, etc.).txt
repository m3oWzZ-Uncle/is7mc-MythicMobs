################################################################
#▄████▄ ██▄  ▄██ ▄██▀▀▀   ▄█████ ██████ ██  ██ ████▄  ██ ▄████▄#
#██▄▄██ ██ ▀▀ ██ ██▄▄▄    ▀▀▀▄▄▄   ██   ██  ██ ██  ██ ██ ██  ██#
#██  ██ ██    ██ ▀█▄▄█▀   █████▀   ██   ▀████▀ ████▀  ██ ▀████▀#
################################################################

 THANK YOU FOR PURCHASING THIS ASSET ! 
 IN THIS FILE, YOU WILL FIND INFORMATION ON HOW TO INSTALL OR CONFIGURATE THIS ASSET.
 
 ## HOW TO MODIFY DAMAGE, COOLDOWN, ITEM NAME,... - SKILL.EXE 'LASER BEAM ABILITY' RPG SKILL##
 
 ################    MMOITEMS    ################ 
 
 ## HOW TO EDIT DAMAGE/COOLDOWN :##

 1. open sword.yml file (plugins/MMOItems/item)
 2. edit damage & cooldown lines
 3. open skills-exe-lazer-beam-ability.yml file (plugins/MMOItems/skill)
 4. edit damage & cooldown lines
 
  ## HOW TO EDIT ITEM NAME/DESCRIPTION: ##

 1. open sword.yml file (plugins/MMOItems/item)
 2. edit name & lore lines
 
 #################################################################################
  ################    MYTHIC CRUCIBLE    ################ 
  
 ## HOW TO EDIT COOLDOWN ##
 
 1. open sKILLs_exe_LASER_BEAM_skills.yml file (plugins/MythicMobs/skills)
 2. edit line 5 (Cooldown: 20)
 
 ## HOW TO EDIT DAMAGE
 
 1. open sKILLs_exe_LASER_BEAM_skills.yml file (plugins/MythicMobs/skills)
 2. edit line 54 (  - damage{a="1";pkb=true;hnp=true;hp=true} ) with a="1" being 1 damage per tick
 3. open skills-exe-lazer-beam-ability.yml file (plugins/MMOItems/skill)
 4. edit damage & cooldown lines
 
  
 ## HOW TO ITEM NAME/DESCRIPTION##
 
 1. open sKILLx_EXE_LASER_BEAM_SWORD.yml file (plugins/MythicMobs/items)
 2. edit lore (line 20) & display (line 9) lines
 
#85f95b3e859fd8372aff0654c4871e6c