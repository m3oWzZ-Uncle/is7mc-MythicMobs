﻿███╗░░░███╗██╗░░░██╗████████╗██╗░░██╗██╗░█████╗░░░░░░░███╗░░░███╗███╗░░░███╗░█████╗░
████╗░████║╚██╗░██╔╝╚══██╔══╝██║░░██║██║██╔══██╗░░░░░░████╗░████║████╗░████║██╔══██╗
██╔████╔██║░╚████╔╝░░░░██║░░░███████║██║██║░░╚═╝█████╗██╔████╔██║██╔████╔██║██║░░╚═╝
██║╚██╔╝██║░░╚██╔╝░░░░░██║░░░██╔══██║██║██║░░██╗╚════╝██║╚██╔╝██║██║╚██╔╝██║██║░░██╗
██║░╚═╝░██║░░░██║░░░░░░██║░░░██║░░██║██║╚█████╔╝░░░░░░██║░╚═╝░██║██║░╚═╝░██║╚█████╔╝
╚═╝░░░░░╚═╝░░░╚═╝░░░░░░╚═╝░░░╚═╝░░╚═╝╚═╝░╚════╝░░░░░░░╚═╝░░░░░╚═╝╚═╝░░░░░╚═╝░╚════╝░

MythicMMC Ch PRESENTS...

Request:
	- MythicMobs-5.2.0 Premium
	- MythicLib-1.4.2
	- MMOCore-1.10.2
	- LibsDisguises
	- ItemsAdder_3.3.0 or Orixen 1.148.2
	- placeholder

Installation Instructions:
STEP 1.1:
You can either use the provided resourcepack zip file provided for your server or you can combine it with your current
resourcepack although it may prompt you that its going to overwrite the that is standard 

STEP 2:
Please make sure you have MythicMobs and MMOCore and ItemsAdder installed, the free versions should work just fine.
Copy both 'MythicMobs' and 'MMOCore' and 'ItemsAdder' or 'Orixen' into your plugins folder of your server.

STEP 3:
Restart the server and check it out

How to use:
	- Run command /mm items give <player> BLACKFLAME

Feel free to come to me for any questions or help at, https://discord.gg/Z7zrFnujD4