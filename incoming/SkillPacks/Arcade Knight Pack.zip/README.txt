Thank you for purchase

Test on 1.21.1
_______________________________________

Requirement: 
• ItemsAdder or Oraxen or Nexo
• PlaceholderAPI
• ProtocolLib
• ModelEngine-4.0.7 
• MythicMobs-5.8.1 Premium
• MMOItems-6.10 or MMOCore-1.13

How to install:
• Drag&Drop file

How to Use with MMOCore:

How to Use with MMOItems:
------------------------------------------------------------------------------------
ARCADE_KNIGHT:
    display: IRON_SWORD:956144
    name: 'Arcade Knight'
    hide-in-game: false
    parent: 'SWORD'
    unident-item:
        name: '&f#prefix#Unidentified Sword'
        lore:
    disable-melee-attacks: true
------------------------------------------------------------------------------------

Skill Info:
  Arcade Barrier | Passive |
  Arcade Slash | Passive |
  Arcade Buffs | Active Skill |
  Arcstrike | Active Skill |
  Cyclone Charge | Active Skill |
  Drone Blaster | Active Skill |
  Arcade Knight Ultimate | Active Skill |
_______________________________________

Please review for this pack once you use it. Thank you very much

Follow me:
- Discord: https://discord.erocavontic.net
- Docs: https://docs.erocavontic.net
- Facebook: https://www.facebook.com/erocavontic/
- Youtube: https://www.youtube.com/channel/UCGwoLgEhb4Pqv1gO7WJ9zBA
- Web: https://erocavontic.net/

_______________________________________

If you encounter any issues, please contact me on https://discord.gg/MCModels

_______________________________________


#10ebc3e12a7b724c737ac85638bad7cd
# FRFyfGtTUgMrfbyB9tLLPax3udxck39gamX1hqdEwPVz