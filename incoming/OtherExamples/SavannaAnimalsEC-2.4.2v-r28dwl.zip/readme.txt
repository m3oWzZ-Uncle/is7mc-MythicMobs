**************************************************************
****************Guide how to extract this pack****************
**************************************************************
SavannaAnimalsMobs.yml   put into the folder \MythicMobs\Mobs
SavannaAnimalsItems.yml  put into the folder \MythicMobs\Items
SavannaAnimalsSkills.yml put into the folder \MythicMobs\Skills
**************************************************************
Please check our discord for MobsSpawnSystem as well as other tutorials how to merge packs 
https://discord.gg/JpbzxJds7G