Thank you for your download!

Discord:
https://discord.gg/JtnczV8GwD

Oraxen:
1. Follow the folder path provided and place the files in their respective locations
2. In minecraft, write command /oraxen reload all


#a39f65f5969b4b6fbe38c7cb51065a86