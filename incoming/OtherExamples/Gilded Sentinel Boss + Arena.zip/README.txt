Enjoy your purchase!

Join the Discord:
https://discord.gg/JtnczV8GwD

MythicMobs:
1. Place the mob file in the Mobs folder. plugins --> MythicMobs --> Mobs
   Place the skill file in the Skills folder. plugins --> MythicMobs --> Skills
2. In minecraft, write command /mm reload

ModelEngine:
1. Drag and drop bbmodel file of the mob inside the blueprints folder. plugins --> ModelEngine --> blueprints
2. In minecraft, write command /meg reload
3. Create the resource pack. plugins --> ModelEngine --> resource pack, select all (assets, pack.mcmeta and pack.png) and download
   OR
   You can download the resource pack.zip after refreshing the page if this is available
4. Place the resource pack in minecraft.

If you want to change how much damage a mob does, go to <mob.name> skills.yml and NOT <mob.name> mob.yml

If you encounter any bugs or have any questions about the product after purchase. Feel free to open a ticket on the McModels discord.

HAVE FUN! :)
#a39f65f5969b4b6fbe38c7cb51065a86