The big mist gate is the gs_mist_gate.bbmodel found in FAWE_arena_schematic\plugins\ModelEngine\blueprints
This should be integrated into your server if you want the mist gate, as well as the .mob file of the model.
#a39f65f5969b4b6fbe38c7cb51065a86