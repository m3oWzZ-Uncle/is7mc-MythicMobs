Thank you for purchase
Merci pour votre achat

------------------------------------
ShizuArt discord :
https://discord.gg/Fq8Bb7stC3
------------------------------------

EN(english) instructions:

!!! Make sure you have backed up your folders before adding a new model pack !!!

!!! Make sure to have PAPI player placeholder: /papi ecloud download player then /papi reload  !!!

##################################################################
Open shizuart_geodes_crusher.zip

ItemsAdder :
   1. Open [For ItemsAdder] folder
   2. Drag & Drop [shizuart_furnitures] folder in your [contents] folder
   3. Drag & Drop [DeluxeMenus] folder in your [plugins] folder
   4. In [DeluxeMenus] folder open [config.yml] and add the two following lines at the end under [gui_menus:](pay attention to indentations)->
  menu_crusher:
    file: geodes_crusher/menu_crusher.yml
   5. Run /iaz
   6. Run /dm reload

N.B:
   To remove the "inventory" title between menu & player's inventory :
     - uncomment (delete all the #) of [minecraft_lang_overwrite] part at the end of [geodes_crusher.yml] in [ItemsAdder/contents/shizuart_furnitures/configs/geodes_crusher]

######################################################################
Oraxen :
   1. Open [For Oraxen] folder
   2. Drag & Drop [items], [pack] and [glyphs] folders in your [Oraxen] folder
   3. Drag & Drop [DeluxeMenus] folder in your [plugins] folder
   4. In [DeluxeMenus] folder open [config.yml] and add the two following lines at the end under [gui_menus:](pay attention to indentations)->
  menu_crusher:
    file: geodes_crusher/menu_crusher.yml
   5. Run /o reload all
   6. Run /dm reload

N.B:
   To remove the "inventory" title between menu & player's inventory :
     - Open [global.json] in [Oraxen/pack/lang] then delete [inventory] title between [" "] for the [container.inventory:] line
   Ex:
     "container.inventory": "",

------------------------------------------------------------------------------

FR(français) instructions:

!!! Assurez-vous d'avoir fait une sauvegarde de vos dossiers avant d'ajouter un nouveau pack de models !!!

Ouvrez shizuart_geodes_crusher.zip

ItemsAdder :
   1. Ouvrez le dossier [For ItemsAdder]
   2. Drag & Drop le dossier [shizuart_furnitures] dans votre dossier [contents]
   3. Drag & Drop [DeluxeMenus] folder in your [plugins] folder
   4. Dans le dossier [DeluxeMenus] ouvrez [config.yml] et ajoutez les deux lignes suivantes à la fin en dessous de [gui_menus:](attention à l'indentation)->
  menu_crusher:
    file: geodes_crusher/menu_crusher.yml
   5. Faites /iaz
   6. Faites /dm reload

N.B:
   Pour supprimer le titre "inventaire" entre le menu et l'inventaire du joueur :
     - uncomment (supprimer toutes les #) de la partie [minecraft_lang_overwrite] à la fin du fichier [geodes_crusher.yml] dans [ItemsAdder/contents/shizuart_furnitures/configs/geodes_crusher]

######################################################################
Oraxen :
   1. Ouvrez le dossier [For Oraxen]
   2. Drag & Drop les dossiers [items], [pack] et [glyphs] dans le dossier [Oraxen]
   3. Drag & Drop le dossier [DeluxeMenus] dans votre dossier [plugins]
   4. Dans le dossier [DeluxeMenus] ouvrez [config.yml] et ajoutez les deux lignes suivantes à la fin en dessous de [gui_menus:](attention à l'indentation)->
  menu_crusher:
    file: geodes_crusher/menu_crusher.yml
   5. Faites /o reload all
   6. Faites /dm reload

N.B:
   Pour supprimer le titre "inventaire" entre le menu et l'inventaire du joueur :
     - Ouvrez [global.json] dans [Oraxen/pack/lang] et supprimer le texte [inventory] entre les [" "] pour la ligne [container.inventory:]
   Ex:
     "container.inventory": "",
#660dbf4f04253e7dcaca85121ac53462