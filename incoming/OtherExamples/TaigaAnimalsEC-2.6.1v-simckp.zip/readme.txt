**************************************************************
****************Guide how to extract this pack****************
**************************************************************
TaigaAnimalsMobs.yml   put into the folder \MythicMobs\Mobs
TaigaAnimalsItems.yml  put into the folder \MythicMobs\Items
TaigaAnimalsSkills.yml put into the folder \MythicMobs\Skills
**************************************************************
Please check our discord for MobsSpawnSystem as well as other tutorials how to merge packs 
https://discord.gg/JpbzxJds7G