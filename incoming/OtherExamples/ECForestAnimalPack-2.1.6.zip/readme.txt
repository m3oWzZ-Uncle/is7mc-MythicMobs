**************************************************************
****************Guide how to extract this pack****************
**************************************************************
Copy whole folder of Mythicmobs over your folder in plugins .
Extract ressource pack and model engine guide is on our discord or on mcmodels 
**************************************************************
Please check our discord for MobsSpawnSystem as well as other tutorials how to merge packs 

https://discord.gg/JpbzxJds7G

# 5137EFNF