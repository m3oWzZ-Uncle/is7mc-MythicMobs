###################################################

	     THANKS FOR YOUR PURCHASE!

###################################################

	  	     SUPPORT!
            https://discord.hyrex.es

Thanks for purchasing & downloading 🎬 HyrexAnimations 🎬. Remember to join our discord if you have any problem, question, suggestion, or bug to report.

- Setup: https://docs.hyrex.es/hyrex-animations#%E2%9A%99%EF%B8%8F-installation
- Documentation: https://docs.hyrex.es/hyrex-animations

- Update changelog: https://docs.hyrex.es/hyrex-animations/changelog/131
#479b90f25d1aaf51181f588240915ded