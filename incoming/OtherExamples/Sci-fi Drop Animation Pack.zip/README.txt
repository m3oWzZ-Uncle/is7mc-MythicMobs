Thank you for purchase
_______________________________________

Test on 1.21.1

Requirement: 
• ItemsAdder or Oraxen (ProtocolLib)
• ModelEngine-4.0.7
• MythicMobs-5.7.2 Premium

How to Install:
• Drag & Drop file

How to Use:
• The drop setting will use the skill: erocavonticSciFiDrop along with specifying the corresponding Attribute.
• Description of Attribute of skill: erocavonticSciFiDrop
  • skillDrop = meta-skill that will work for players who Interact with Sci-fi Drop (Requires a skill to activate or an in-line skill.)
  • dropTier = Assign Tiers to inform players of the Tier level of dropped items. The full list of Tiers includes: common, uncommon, rare, epic, legendary, mythic
  • chance = The chance of dropping an item from the drop table. The chance is a percentage value between 0-100 (If this attribute is not added, the drop chance will be 100%.)
  • throwDrop = Set up so that when the Sci-fi Drop is dropped, it will throw the Sci-fi Drop around. (If this attribute is not added, it will not throw Sci-fi Drop.)
  • playerKill = Set to "true" to allow only the player who made the kill to receive the item. Default is "false."
  • dropTime = Set how long the dropped item will remain. '20 = 1 second.' Default is '200 = 10 seconds.'
  • showName = Configure whether to display the name of the player who drops items when 'playerKill=true'. The default value is true.

• Example usage: - skill:erocavonticSciFiDrop{skillDrop=erocavontic_skill_test_drop_a;dropTier=common;chance=100} @self ~onDeath
• When a Mob is killed, the Sci-fi Drop Animation will be dropped in the form of a common Tier with a 100% chance. When interacted with, it will grant the skill 'erocavontic_skill_test_drop_a' to the player.

• If you want to see more configuration examples, sample Drops for Mobs and Skills have been made in the following file with additional details.
_______________________________________

Please review for this pack once you use it. Thank you very much

Follow me:
- Discord: https://discord.erocavontic.net
- Docs: https://docs.erocavontic.net
- Facebook: https://www.facebook.com/erocavontic/
- Youtube: https://www.youtube.com/channel/UCGwoLgEhb4Pqv1gO7WJ9zBA
- Web: https://erocavontic.net/

_______________________________________

If you encounter any issues, please contact me on https://discord.gg/MCModels

_______________________________________


#fda468e067d6f05081a897d2ca030ff4