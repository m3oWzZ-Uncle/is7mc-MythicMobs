Thank you very much for purchasing one of our resources on MCModels.net!

DESCRIPTION
===========

This resource contains:
------------------------
1. Raw Files
   - PNG images of the item tags and tooltips.

2. Drag & Drop
   - A ready-to-use Drag & Drop folder for quick and easy setup (for Nexo).

3. Tutorial
   - A full written tutorial explaining how to use custom tooltips and item tags.

4. Texturepack
   - A Minecraft texturepack that includes custom tooltips.
     - (Custom item tags are only available when using Nexo.)



GETTING STARTED (FOR BEGINNERS) - NEXO
======================================

If you are new to using Nexo or similar plugins, follow these simple steps to set up the resource on your server:

1. Open the file manager in your server hosting panel.

2. Drag the **"Nexo"** folder (found inside the **"Drag and Drop"** folder) into your server's **plugins** folder.

   - This will automatically merge the included Nexo folder with your server's existing Nexo folder.
   - If it does not merge automatically, manually move the contents into the correct directories.

3. Start your server and type the following command in the console or in-game:

   /nexo reload

   - This command reloads the server's texturepack and refreshes the Nexo configuration.

4. After reloading, you can find example items under the **"lztooltips"** category inside Nexo.

   /nexo inv   -   Command for Nexos Inventory

5. Have fun customizing your Minecraft items with new tooltips and tags!



SUPPORT
=======

If you have any questions or issues, we offer support through our Discord server.

- To get help, join our Discord via the link provided at purchase and open a support ticket.
- For detailed Nexo documentation and guides, visit:  
  https://docs.nexomc.com



CONTACT
=======

- Discord: **LZBlocks**
- Email: **lzblocks@outlook.com**



THANK YOU
=========

If you enjoy this resource, we would love it if you could leave a review on MCModels.net!

Author(s): **LZLeon (LZBlocks)**

# 87904O74K0EVM12DJ0TWP