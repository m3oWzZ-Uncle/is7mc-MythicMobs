**************************************************************
****************Guide how to extract this pack****************
**************************************************************
InsectsMobs.yml   put into the folder \MythicMobs\Mobs
InsectsItems.yml  put into the folder \MythicMobs\Items
InsectSkills.yml put into the folder \MythicMobs\Skills
**************************************************************
Please check our discord for MobsSpawnSystem as well as other tutorials how to merge packs 

https://discord.gg/JpbzxJds7G

# 062PF9NU9STD7ZU5DRM