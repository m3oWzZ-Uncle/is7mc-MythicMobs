Hello, thank you for purchasing this product from BreadBuilds

Support discord: https://discord.gg/grZBrmSB8F

Terms and Conditions:
1. By purchasing this product you automatically agree to the Terms of Service.
2. You may not resell, distribute, or claim this product as your own.
3. There are no refunds. All purchases are final due to the digital nature of the product.
4. We are not responsible if you accidentally delete or lose purchased products. We are not responsible for a refund or replacement.
5. These Terms of Service may change at any time without notification.


Full terms of service: https://www.breadbuilds.com/tos
#3f15cc91270e0e9ad8ae57702cbc31de